#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>

int runcmd(char **cmd);
int Parse(char **cmd,char *temp);

int main()
{
  char *cmd[100], temp[100];
  int i=-1, m=0;
   while(temp[i]!=EOF)
    {
      printf("\n$");  /*command line symbol*/
      while(temp[i]!='\n')
	{
	  i++;
	  temp[i]=getchar(); /*grabing char by char from command line*/
          if(temp[i]==EOF)
          {
             exit(0);
          }
        }
 
      Parse(cmd, temp);    /*parsing input into a 2 dimensional array so that execvp can use it*/
      runcmd(cmd);         /*executes child process to run shell command*/
      i=-1;
    } 
}

int runcmd(char **cmd)
{
  int status;
  pid_t pid=fork();

 if(pid<0)   /* if it failed*/
  {
    printf("could not make child process\n");
  }
  else if(pid==0)   /*child process*/
  {
    printf("it is %d", wait(&status));
    execvp(*cmd, cmd);
    exit(0);
  }
  else if(pid!=wait(&status))                /*wait for child process to end*/
  {
    printf("parent did not wait for child to end");
  }
  else
  {
    // exit(0);
  }
}


int Parse(char **cmd, char *temp)
{
  int i=0, flag=0, col=0;
  while(temp[i]!='\n')
    {
      if((temp[i]==' ' || temp[i]=='\t') && flag==1)  /*NULLing spaces in input*/
        {
          temp[i]='\0';   
	  flag=0;
	}
      else if(flag==0) 
	{
	  cmd[col]=&temp[i];
	  flag=1;
	  col++;
	}
      i++;
    }
  temp[i]='\0';  /* nullifying the \n character from input*/
}
