#include "wordlist.hpp"
using namespace std;

class file
{
         public:
          void readfile(wordlist &list);
};


